package com.android.meddata.interfaces;

/**
 * Created by CHANDRASAIMOHAN on 11/9/2015.
 */
public interface SendDataDialogListener {
    void onFinishDialog(String inputText);
}