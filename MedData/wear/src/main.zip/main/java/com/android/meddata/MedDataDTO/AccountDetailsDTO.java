package com.android.meddata.MedDataDTO;

/**
 * Created by CHANDRASAIMOHAN on 10/25/2015.
 */
public class AccountDetailsDTO {
    private String accountImage;
    private String physicianName;
    private String physcianEmail;
}
