package com.android.meddata.interfaces;

public interface OMSReceiveListener {
    public void receiveResult(String result);
}
